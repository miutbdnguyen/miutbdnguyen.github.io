package wap;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "CalculatorServlet", value = "/calculate")
public class CalculatorServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        String sum1 = request.getParameter("sum1");
        String sum2 = request.getParameter("sum2");
        String mul1 = request.getParameter("mul1");
        String mul2 = request.getParameter("mul2");
        String result1 = "", result2 = "";
        if(!sum1.isEmpty() && !sum2.isEmpty()) {
            result1 = String.valueOf(Integer.parseInt(sum1) + Integer.parseInt(sum2));
        }

        if(!mul1.isEmpty() && !mul2.isEmpty()) {
            result2 = String.valueOf(Integer.parseInt(mul1) * Integer.parseInt(mul2));
        }

        PrintWriter writer = response.getWriter();
        writer.write("{ \"sum\": " + (result1.isEmpty() ? "\"\"" : result1) + ", \"mul\": " + (result2.isEmpty() ? "\"\"" : result2) + "}");
    }
}
