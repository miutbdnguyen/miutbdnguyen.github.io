# DEPLOYMENT QUIZ
1. What is the purpose of the directory structure given on p. 30?
> To store the servlet project.

2. What is the purpose of the directory structure given on p. 31?
> To store the executable files of project.

3. Why do you need to be in the project1 directory for step 5?
> To locate the file that needs to be compile.

4. Why is the copying of step 6 necessary?
> Because executable needs to be put under webapps folder in order to run by Tomcat.

5. Where is the name of the web app defined? Try changing it.
> in web.xml

6. Why is step 9 necessary? Try changing display text in the servlet. What steps are necessary for your changes to appear in the browser?
> N/A

7. Describe an interesting problem you encountered (if any) and how you solved it
> I don't have any problem.

